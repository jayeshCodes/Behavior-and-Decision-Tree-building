enum ActionType
{
    WANDER,
    PATHFIND_TO_CENTER, // to center of screen
    PATHFIND_AWAY_FROM_OBSTACLE
};
