enum ActionType
{
    WANDER,
    PATHFIND_TO_CENTER, // to center of screen
    ZIGZAG,
    EVADE,
    PURSUE,
    DANCE
};
